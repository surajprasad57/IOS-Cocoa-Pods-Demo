//
//  ViewController.swift
//  CocoaPodsDemo
//
//  Created by Suraj Prasad on 07/03/19.
//  Copyright © 2019 Suraj Prasad. All rights reserved.
//
import UIKit
import TPKeyboardAvoiding
class ViewController: UIViewController {
    //MARK:- IBOutlets
    @IBOutlet weak var usekeyboardPod: TPKeyboardAvoidingTableView!
    @IBOutlet weak var nameLabel: UILabel!
    //MARK:- Global Variables
    let dataSourceName = ["Name","Age","Mob","house no","Father's Name","College","Course","NickName","Skills","Matric CGPA", "Intermediate CGPA","BTech Aggregate","Hobbies","Website","Social Media","LinkedIn"]
    var rowNo = 0
    //MARK:- life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    //MARK:- IBActions
    @IBAction func nextButton(_ sender: Any) {
        if let cv = storyboard?.instantiateViewController(withIdentifier: "CollectionVC") as? CollectionVC {
            self.navigationController?.pushViewController(cv, animated: true)
        }
    }
}
//MARK:- Extension for TableView
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSourceName.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "FormCell") as? FormCell {
            cell.formLabel.text = dataSourceName[indexPath.row]
            
            return cell
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}
