//
//  FormCell.swift
//  CocoaPodsDemo
//
//  Created by Suraj Prasad on 08/03/19.
//  Copyright © 2019 Suraj Prasad. All rights reserved.
//

import UIKit

class FormCell: UITableViewCell {

    @IBOutlet weak var formLabel: UILabel!
    @IBOutlet weak var formTextField: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
