//
//  CollectionVC.swift
//  CocoaPodsDemo
//
//  Created by Suraj Prasad on 08/03/19.
//  Copyright © 2019 Suraj Prasad. All rights reserved.
//

import UIKit
import Toast_Swift
import Kingfisher
class CollectionVC: UIViewController {
    //MARK:- IBOutlets
    @IBOutlet weak var collectionView: UICollectionView!
    //MARK:- Global Variables
    var rowNo = 0
    let dataSourceName = ["Name","Age","Mob","house no","Father's Name","College","Course","NickName","Skills"]
    let foodNames = ["Special Egg Dish","Pizza Combo","Pizza Italiano","Veggie Mega Burger","Mc French Fries","Non-Veg Special","Mix Salad","Special Egg Dish","Pizza Combo","Pizza Italiano","Veggie Mega Burger","Mc French Fries","Non-Veg Special","Mix Salad"]
    let foodImages = ["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBLHPG_xaZgUE-pn8zeVWhpKuboRFekvUjiKdBZdmLy-TYeDq6FQ","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvFr1tSzWZ6ZifebZ87qasJbz8WA0r6F2CAy2z2KXjYYQT1Eg","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTW5l17JFnllpXxiSeK8F7cxqwdTPQPtcBXnV-kZ5oaIDNpbX_4","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ03t12xdP3zzpIb352HsPxj4fyIbBYOjLgLVRQwF-bPeG0PBiJwA","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFslrCbFSYTS6mO_uRS8_XbIV2keBtD03yIm8_rK6k6tKDBZ35","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJKopaspTodlY1nR8_NJx5GiNGR9dPbkgwCY63IIjM9yDfSNh1Tg","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkDLcILX_vZCS8WQbYgTpK4V-YlVAwFfL7qh-f5Q6p0D0SpEB8yw","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBLHPG_xaZgUE-pn8zeVWhpKuboRFekvUjiKdBZdmLy-TYeDq6FQ","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvFr1tSzWZ6ZifebZ87qasJbz8WA0r6F2CAy2z2KXjYYQT1Eg","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTW5l17JFnllpXxiSeK8F7cxqwdTPQPtcBXnV-kZ5oaIDNpbX_4","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ03t12xdP3zzpIb352HsPxj4fyIbBYOjLgLVRQwF-bPeG0PBiJwA","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFslrCbFSYTS6mO_uRS8_XbIV2keBtD03yIm8_rK6k6tKDBZ35","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJKopaspTodlY1nR8_NJx5GiNGR9dPbkgwCY63IIjM9yDfSNh1Tg","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkDLcILX_vZCS8WQbYgTpK4V-YlVAwFfL7qh-f5Q6p0D0SpEB8yw"]
    //MARK:- lifeCycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionViewCell")
    }
    //MARK:- Gesture Action
    @objc func tapNameAction(_ sender: UITapGestureRecognizer) {
        if sender.state == .ended {
            print("Name tapped")
            let location = sender.location(in: collectionView)
            if let indexPath = collectionView.indexPathForItem(at: location) {
                print("tapped row \(indexPath.row)")
                self.rowNo = indexPath.row
            }
            print("Food Name: \(foodNames[rowNo])")
            self.view.makeToast("\(foodNames[rowNo]) clicked")
        }
    }
}
//MARK:- Extension for CollectionView
extension CollectionVC:  UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return foodNames.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as? CollectionViewCell {
            cell.gridFoodName.text = foodNames[indexPath.row]
            cell.gridFoodImage.kf.setImage(with: URL(string: foodImages[indexPath.row]))
            
            let tapName = UITapGestureRecognizer(target: self, action: #selector(tapNameAction(_:)))
            tapName.numberOfTapsRequired = 1
            cell.gridFoodName.addGestureRecognizer(tapName)
            return cell
        }
        return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        print(collectionView.frame.width)
        return CGSize(width:view.frame.width/2-2, height: 200)
    }
}
